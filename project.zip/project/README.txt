OCR H446 PROJECT, Cian Anderson

this is the release version of my project

contains all dynamic libraries, texture files, custom room files, and the exe

launching directly from the exe or from CMD causes the level to always generate in the same way for an unknown reason

launching from a git bash terminal with "./Program" seems to fix this issue 
 (likely caused by pseudo-random generation being different for some environments)

keybinds are hard-coded
WASD for movement
LMB for shoot
Q for interact (with doors)
M for mini-map

other keys:
H for debug mode
P to regenerate the current level
O to set HP to 100

if it doesnt work, cry about it :)